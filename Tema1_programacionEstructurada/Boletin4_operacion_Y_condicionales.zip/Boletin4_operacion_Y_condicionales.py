'''
Created on Sep 19, 2022

@author: Rafa Moreno
'''
'''
#Dados los catetos de un triángulo rectángulo, calcular su hipotenusa.
print("Buenas, vamos a calcular la hipotenusa")
cateto1=int(input("Dime la longitud del primer cateto "))
cateto2=int(input("Dime la longitud del segundo cateto "))
hipotenusa=(cateto1*2)+(cateto2*2)
print("La longitud de la hipotenusa es",hipotenusa)

print("------")

#Escribir un programa que convierta un valor dado en grados Fahrenheit a grados Celsius.

print("Vamos a pasar de grados Celsius a grados Fahrenheit")
grados=int(input("Introduce los grados celsius: "))
grados_F=(grados*9/5)+32
print("%s grados Celsius son %s grados Fahrenheit" %(grados, grados_F))
print("--------")

#Calcular la media de tres números pedidos por teclado

print("Vamos a hacer la media de 3 numeros")
print()
numero1=int(input("Introduce un numero: "))
numero2=int(input("Introduce un numero: "))
numero3=int(input("Introduce un numero: "))

media=(numero1 + numero2 + numero3)/3
print(media)

#Una tienda ofrece un descuento del 15% sobre el total de la compra y un cliente desea saber
#cuanto deberá pagar finalmente por su compra.

compra=int(input("Cuanto cuesta el producto comprado?: "))
descuento=compra*15/100
precio_final=compra-descuento
print("El precio final es de %s euros"%(precio_final))


#Pide al usuario dos números y muestra la "distancia" entre ellos (el valor absoluto de su
#diferencia, de modo que el resultado sea siempre positivo).
print("Vamos a calcular la distancia entre dos puntos")
numero1=int(input("Introduce el primer punto: "))
numero2=int(input("Introduce el segundo punto: "))
resultado=abs(numero1-numero2)
print("La distancia entre los puntos es de %s"%(resultado))

#Pide al usuario dos pares de números x1,y2 y x2,y2, que representen dos puntos en el plano.
#Calcula y muestra la distancia entre ellos.

x1=int(input("Introduce el valor del primer punto en X: "))
y1=int(input("Introduce el valor del primer punto en Y: "))
print("El primer punto es %s,%s"%(x1,y1))
print()
x2=int(input("Introduce el valor del segundo punto en X: "))
y2=int(input("Introduce el valor del segundo punto en Y: "))
print("El segundo punto es %s,%s"%(x2,y2))
resultado=((x2-x1)**2+(y2-y2)**2)**(1/2)
print("La distancia entre los puntos es de %s"%(resultado))

#Realizar un algoritmos que lea un número y que muestre su raíz cuadrada y su raíz cúbica.
#Python no tiene ninguna función predefinida que permita calcular la raíz cúbica, ¿cómo se puede calcular?

numero=int(input("Introduce un numero: "))
raiz_cua=(numero)**(1/2)
raiz_cubi=(numero)**(1/3)
print("La raiz cuadrada de %s es %s y la raiz cubica es %s"%(numero, raiz_cua, raiz_cubi))

#Diseñar un algoritmo que nos diga el dinero que tenemos (en euros y céntimos) después de
#pedirnos cuantas monedas tenemos de 2e, 1e, 50 céntimos, 20 céntimos o 10 céntimos).

print("Que cantidad de dinero tienes? Veamoslo")

monedas2=int(input("Cuantas monedas de dos euros tienes?: "))
monedas1=int(input("Cuantas monedas de un euros tienes?: "))
moneda50cent=int(input("Cuantas monedas de 50 centimos tienes?:"))
moneda20cent=int(input("Cuantas monedas de 20 centimos tienes?: "))
moneda10cent=int(input("Cuantas monedas de 10 centimos tienes?: "))

if monedas2<0 or monedas1<0 or moneda50cent<0 or moneda20cent<0 or moneda10cent<0:
    print("No puede haber monedas negativas")
else:

    euros=(2*monedas2)+(1*monedas1)
    centimos=(moneda50cent*50)+(moneda20cent*20)+(moneda10cent*10)
    
    if centimos<100:
        print("Tienes %s euros y %s centimos"%(euros, centimos))
    else:
        cents=centimos%100
        eur=euros+(centimos//100)
        print("Tienes %s euros y %s centimos"%(eur, cents))

'''
#Realiza un algoritmo que calcule la potencia, para ello pide por teclado la base y el
#exponente. Pueden ocurrir tres cosas:
#◦ El exponente sea positivo, sólo tienes que imprimir la potencia.
#◦ El exponente sea 0, el resultado es 1.
#◦ El exponente sea negativo, el resultado es 1/potencia con el exponente positivo

print("Vamos a calcular la potencia de un numero")
base=int(input("Cual es la base de su operacion?: "))
expon=int(input("Cual es el exponente de su operacion?: "))

if expon>0:
    print("El resultado es",base**expon)
elif expon==0:
    print("El resultado es 1")
else:
    print("El resultado es",1/(base**expon))
    
#Programa que lea 3 datos de entrada A, B y C. Estos corresponden a las dimensiones de los
#lados de un triángulo. El programa debe determinar que tipo de triangulo es, teniendo en
#cuenta los siguiente:
#◦ Si se cumple Pitágoras entonces es triángulo rectángulo
#◦ Si sólo dos lados del triángulo son iguales entonces es isósceles.
#◦ Si los 3 lados son iguales entonces es equilátero.
#◦ Si no se cumple ninguna de las condiciones anteriores, es escaleno.  

lado1=int(input("Cual es la dimension de su primer lado?: "))
lado2=int(input("Cual es la dimension de su segundo lado?: "))
lado3=int(input("Cual es la dimension de su tercer lado?: "))





